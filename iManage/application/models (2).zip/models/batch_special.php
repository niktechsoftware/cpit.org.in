<?php
	class batch_special extends CI_Model{
		
	}
